<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Админ панель</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-lg-3">
            <div class="widget-small primary coloured-icon">
                <i class="icon fa fa-users fa-3x"></i>
                <div class="info">
                    <h4>Продукты</h4>
                    <p><b><?php echo e($products_count); ?></b></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="widget-small info coloured-icon">
                <i class="icon fa fa-tags fa-3x"></i>
                <div class="info">
                    <h4>Категории</h4>
                    <p><b><?php echo e($categories_count); ?></b></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="widget-small warning coloured-icon">
                <i class="icon fas fa-store fa-3x"></i>
                <div class="info">
                    <h4>Заведения</h4>
                    <p><b><?php echo e($spots_count); ?></b></p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="widget-small danger coloured-icon">
                <i class="icon fa fa-th fa-3x"></i>
                <div class="info">
                    <h4>Аттрибуты</h4>
                    <p><b><?php echo e($attribute_values_count); ?></b></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\emojisushi\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>