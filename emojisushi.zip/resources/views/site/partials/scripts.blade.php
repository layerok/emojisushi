<script src="{{ asset('frontend/js/jquery.min.js') }}" type="text/javascript"></script>

<script src="{{ asset('frontend/js/jquery.validate.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/jquery.form.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/jquery.tmpl.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/jquery.mask.min.js') }}" type="text/javascript"></script>

<script src="{{ asset('frontend/js/notify.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/layerok.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/gsap/gsap.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/gsap/ScrollTrigger.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/animations.js') }}" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js" integrity="sha512-IsNh5E3eYy3tr/JiX2Yx4vsCujtkhwl7SLqgnwLNgf04Hrt9BT9SXlLlZlWx+OK4ndzAoALhsMNcCmkggjZB1w==" crossorigin="anonymous"></script>
{{--<script src="{{ asset('frontend/plugins/fancybox/fancybox.min.js') }}" type="text/javascript"></script>--}}
<script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="{{ asset('frontend/js/cart.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/script.js') }}" type="text/javascript"></script>





@stack('scripts')
