<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">

<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontend/images/favicon.ico')); ?>">
<link href="<?php echo e(asset('frontend/fonts/fontawesome/css/fontawesome-all.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/fancybox/fancybox.min.css')); ?>" type="text/css" rel="stylesheet">

<!-- Magnific Popup core CSS file -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" integrity="sha512-+EoPw+Fiwh6eSeRK7zwIKG2MA8i3rV/DGa3tdttQGgWyatG/SkncT53KHQaS5Jh9MNOT3dmFL0FjTY08And/Cw==" crossorigin="anonymous" />
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/tachyons.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom-tachyons.css')); ?>"/>
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css">
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">





<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\emojisushi\resources\views/site/partials/styles.blade.php ENDPATH**/ ?>