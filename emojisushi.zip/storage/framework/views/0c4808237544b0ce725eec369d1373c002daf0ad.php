<header class=" flex flex-column items-center pt3">
    <div class="w-100 mw7 ph3 relative">
        <section class="w-100 flex flex-wrap flex-nowrap-l justify-between">
            <!-- Телефоны -->
            <div class="order-0 w-50 flex flex-column">
                <div class="flex items-center mb2">
                    <div class="nested-img mr2"><img src="<?php echo e(asset('img/phone.png')); ?>" alt=""></div>
                    <div>3 8(067) 373 26 70</div>
                </div>
                <div class="flex items-center mb2">
                    <div class="nested-img mr2"><img src="<?php echo e(asset('img/phone.png')); ?>" alt=""></div>
                    <div>3 8(067) 373 26 70</div>
                </div>
                <div class="flex items-center mb2">
                    <div class="nested-img mr2"><img src="<?php echo e(asset('img/phone.png')); ?>" alt=""></div>
                    <div>3 8(067) 373 26 70</div>
                </div>

            </div>
            <!-- Лого -->
            <a class="w-100 order-1 order-0-l flex justify-center" href="<?php echo e(url('/')); ?>" class="nested-img">
                <img src="<?php echo e(asset('img/logosumoist.png')); ?>" alt="">
            </a>
            <sumoist-cart></sumoist-cart>
            <sumoist-cart-pop-up></sumoist-cart-pop-up>

        </section>
        <?php echo $__env->make('site.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</header>


<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\ecommerce_new\ecom\resources\views/site/partials/header.blade.php ENDPATH**/ ?>