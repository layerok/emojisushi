
<div id="nav" class="w-100 flex-column z-4 ">

    <nav class="w-auto bt bb b--dark-red bg-black mb2 flex ">
        <ul class="w-100 ma0 pv3 list flex justify-between items-center ph2 overflow-y-auto">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li  class="mv1 flex-shrink-0"><!---->
                    <a href="/category/<?php echo e($category->slug); ?>"  class="<?php if(isset($slug)): ?><?php if($slug == $category->slug): ?> bg-dark-red <?php endif; ?> <?php endif; ?> ph3-ns ph1 pv1 br-pill link mr2-ns mr1 hover-bg-dark-red hover-white white ">
                        <span class="ph1"><?php echo e($category->name); ?></span>
                    </a>
                </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </ul>
        <?php $is_second_popup = true; ?>
        <div class="cart-in-menu dn ">
            <?php echo $__env->make('site.partials.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </nav>
</div>






<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\emojisushi\resources\views/site/partials/nav.blade.php ENDPATH**/ ?>