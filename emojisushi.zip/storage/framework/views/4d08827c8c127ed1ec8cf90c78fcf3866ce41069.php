<?php $__env->startSection('title'); ?> <?php echo e($pageTitle); ?> <?php $__env->stopSection(); ?>
=<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-shopping-bag"></i> <?php echo e($pageTitle); ?> - <?php echo e($subTitle); ?></h1>
        </div>
    </div>
    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row user">
        <div class="col-md-3">
            <div class="tile p-0">
                <ul class="nav flex-column nav-tabs user-tabs">
                    <li class="nav-item"><a class="nav-link active" href="#general" data-toggle="tab">Основные</a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-9">
            <div class="tab-content">
                <div class="tab-pane active" id="general">
                    <div class="tile">
                        <form action="<?php echo e(route('admin.products.store')); ?>" method="POST" role="form">
                            <?php echo csrf_field(); ?>
                            <h3 class="tile-title">Данные товара</h3>
                            <hr>
                            <div class="tile-body">
                                <div class="form-group">
                                    <label class="control-label" for="name">Имя</label>
                                    <input
                                        class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                        type="text"
                                        placeholder="Введите имя продукта"
                                        id="name"
                                        name="name"
                                        value="<?php echo e(old('name')); ?>"
                                    />

                                    <div class="invalid-feedback active">
                                        <i class="fa fa-exclamation-circle fa-fw"></i> <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="poster_id">ID в системе Poster</label>
                                    <input
                                        class="form-control <?php if ($errors->has('poster_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('poster_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                        type="text"
                                        placeholder="Введить id товара"
                                        id="poster_id"
                                        name="poster_id"
                                        value="<?php echo e(old('poster_id')); ?>"

                                    />
                                    <div class="invalid-feedback active">
                                        <i class="fa fa-exclamation-circle fa-fw"></i> <?php if ($errors->has('poster_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('poster_id'); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="control-label" for="categories">Категории</label>
                                            <select name="categories[]" id="categories" class="form-control" multiple>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>" ><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label" for="price">Цена</label>
                                            <input
                                                class="form-control <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                                type="text"
                                                placeholder="Введите цену товара"
                                                id="price"
                                                name="price"
                                                value="<?php echo e(old('price')); ?>"
                                            />
                                            <div class="invalid-feedback active">
                                                <i class="fa fa-exclamation-circle fa-fw"></i> <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label" for="weight">Вес</label>
                                            <input
                                                class="form-control"
                                                type="text"
                                                placeholder="Введите вес товара"
                                                id="weight"
                                                name="weight"
                                                value="<?php echo e(old('weight')); ?>"
                                            />
                                            <div class="invalid-feedback active">
                                                <i class="fa fa-exclamation-circle fa-fw"></i> <?php if ($errors->has('weight')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight'); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label" for="sort_order">Порядок сортировки</label>
                                            <input
                                                class="form-control <?php if ($errors->has('sort_order')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sort_order'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                                type="text"
                                                placeholder="Введите позицию товара"
                                                id="sort_order"
                                                name="sort_order"
                                                value="<?php echo e(old('sort_order')); ?>"
                                            />
                                            <div class="invalid-feedback active">
                                                <i class="fa fa-exclamation-circle fa-fw"></i> <?php if ($errors->has('sort_order')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sort_order'); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label" for="unit">Единица измерения</label>
                                            <input
                                                class="form-control"
                                                type="text"
                                                placeholder="Введите единицу измерения"
                                                id="unit"
                                                name="unit"
                                                value="<?php echo e(old('unit')); ?>"
                                            />
                                            <div class="invalid-feedback active">
                                                <i class="fa fa-exclamation-circle fa-fw"></i> <?php if ($errors->has('unit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('unit'); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>


                                <div class="form-group">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input class="form-check-input"
                                                   type="checkbox"
                                                   id="hidden"
                                                   name="hidden"
                                            />Активный
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="tile-footer">
                                <div class="row d-print-none mt-2">
                                    <div class="col-12 text-right">
                                        <button class="btn btn-success" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Сохранить продукт</button>
                                        <a class="btn btn-danger" href="<?php echo e(route('admin.products.index')); ?>"><i class="fa fa-fw fa-lg fa-arrow-left"></i>Назад</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/select2.min.js')); ?>"></script>
    <script>
        $( document ).ready(function() {
            $('#categories').select2();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\emojisushi\resources\views/admin/products/create.blade.php ENDPATH**/ ?>