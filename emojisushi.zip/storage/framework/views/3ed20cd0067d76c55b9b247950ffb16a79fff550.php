<footer class=" flex justify-center mv5">
    <div class="w-100 mw7 ph3 flex flex-row-l flex-column items-center justify-center">
        <!-- Лого -->
        <a href="<?php echo e(url('/')); ?>" class="nested-img mb3 pb2 mb0-l pb0-l">
            <img src="<?php echo e(asset('img/logosumoist.png')); ?>" alt="">
        </a>
        <!-- Телефоны -->
        <div class=" ml4-l pl3-l flex flex-column">
            <div class="flex items-center mb2">
                <div class="nested-img mr2"><img src="<?php echo e(asset('img/phone.png')); ?>" alt=""></div>
                <div>3 8(067) 373 26 70</div>
            </div>
            <div class="flex items-center mb2">
                <div class="nested-img mr2"><img src="<?php echo e(asset('img/phone.png')); ?>" alt=""></div>
                <div>3 8(067) 373 26 70</div>
            </div>
            <div class="flex items-center mb2">
                <div class="nested-img mr2"><img src="<?php echo e(asset('img/phone.png')); ?>" alt=""></div>
                <div>3 8(067) 373 26 70</div>
            </div>

        </div>
    </div>


</footer>
<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\ecommerce_new\ecom\resources\views/site/partials/footer.blade.php ENDPATH**/ ?>