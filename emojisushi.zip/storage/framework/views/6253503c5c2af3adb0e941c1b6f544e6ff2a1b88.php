<?php $__env->startSection('title', $category->name); ?>
<?php $__env->startSection('content'); ?>
    <section class="flex flex-column items-center pt3">
        <div class="w-100 mw7 flex flex-wrap">
            <?php $__empty_1 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="pa3 w-100 w-50-ns w-33-l ">
                    <div class="br3 ba b--red pa3 ">
                        <div class="flex flex-column mt1 mb2 ">
                            <div class="nested-img">
                                <?php if($product->images->count() > 0): ?>
                                    <img src="<?php echo e(asset('storage/'.$product->images->first()->full)); ?>" alt="">
                                <?php else: ?>
                                    <img src="https://via.placeholder.com/300x200" alt="">
                                <?php endif; ?>
                            </div>
                            <h3 class="f3 fw5 mt3 mb0"><?php echo e($product->name); ?></h3>
                            <p class="f6 fw5 mv2">Креветка Тигровая в темпуре, японский майонез, Икра масага, огурец</p>
                            <p class="self-end f4 mt2 mb1">210 г</p>
                            <div class="flex justify-between">
                                <button class="dn w4 bg-dark-red tc white pa3 bn br-pill bg-animate hover-bg-red pointer">В корзину</button>
                                <div>
                                    <div class="flex bg-dark-red w4 white mb1 br-pill overflow-hidden ">
                                        <button class="w-third bn  pv3 ph2 bg-inherit white bg-animate hover-bg-red pointer">-</button>
                                        <div class="w-third tc pv3">233</div>
                                        <button class="w-third bn  pv3 ph2 bg-inherit white bg-animate hover-bg-red pointer">+</button>
                                    </div>
                                </div>
                                <div class=" fw5"><span class="f2"><?php echo e($product->price); ?></span> <span class="f4"><?php echo e(config('settings.currency_symbol')); ?></span></div>
                            </div>



                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="ph3">Товары не найдеры в категории <?php echo e($category->name); ?>.</p>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\ecommerce_new\ecom\resources\views/site/pages/category.blade.php ENDPATH**/ ?>