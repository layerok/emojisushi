<footer class=" flex justify-center mv5">
    <div class="w-100 mw7 ph3 bg-black flex flex-row-l flex-column items-center justify-center">
        <!-- Лого -->
        <a href="" class="nested-img mb3 pb2 mb0-l pb0-l">
            <img src="/img/logosumoist.png" alt="">
        </a>

        <!-- Телефоны -->
        <div  class=" ml4-l pl3-l flex flex-column">
            <div class="flex items-center mb2">
                <div class="nested-img mr2"><img src="/img/phone.png" alt=""></div>
                <a href="tel:+380673732670" target="_blank" class="link white hover-dark-red f6 f5-ns">+380 67‒373‒26‒70</a>
            </div>
            <div class="flex items-center mb2">
                <div class="nested-img mr2"><img src="/img/phone.png" alt=""></div>
                <a href="tel:+380991776303" target="_blank" class="link white hover-dark-red f6 f5-ns">+380 99‒177‒63‒03</a>
            </div>
            <div class="flex items-center mb2">
                <div class="nested-img mr2 "><img src="/img/instagram.png" alt=""></div>
                <a href="https://www.instagram.com/sumoist_od/" target="_blank" class="f6 f5-ns white hover-dark-red link">@sumoist_od</a>
            </div>

        </div>




    </div>


</footer>
