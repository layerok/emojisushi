<div   class="pa3-l pa2 w-50 w-50-ns w-33-l ">
    <div class="br3 ba b--dark-red pa3-l pa2 h-100">
        <div class="flex flex-column pb1 pb2 h-100 relative">
            <div class="nested-img flex flex-shrink-0 justify-center "  >
                <?php if( count($product->images) > 0): ?>
                    <?php  $path = '/storage/'. $product->images()->first()->value('full'); ?>
                <?php else: ?>
                    <?php
                        if(isset($product->image)){
                            $path = $product->image;
                        }else{
                            $path ='/storage/' . 'img/default.jpg';
                        }

                    ?>
                <?php endif; ?>
                    <img class="self-center align-center-start" style=" width:auto; max-height:220px" src="<?php echo e($path); ?>" alt="">
                <!--<div class="h4 contain" :style="{backgroundImage: 'url(' + item.poster_image + ')'}"  ></div>-->
            </div>
            <form action="<?php echo e(route('cart.manipulate')); ?>" method="post" data-buy class="flex flex-column justify-between h-100">
                <?php echo csrf_field(); ?>
                <div>
                    <h3  class="f3-l f5 fw5 mv3 mb0"><?php echo e($product->name); ?></h3>
                    <div class="f6-l f7 fw5 mb2">
                        <p class="flex flex-column flex-row-l mb3 bg-white-10 br2 modificator bg-black">
                            <?php
                                $modificators = [];
                                $ingredients = [];
                                $sharpness = [];
                                $i = -1;
                            ?>
                            <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productAttribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $productAttribute->attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attributeValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($attributeValue->attribute_id == 3): ?>

                                        <?php $ingredients[] = $attributeValue->value ?>
                                    <?php endif; ?>
                                    <?php if($attributeValue->attribute_id == 6): ?>

                                        <?php $sharpness[] = $attributeValue ?>
                                    <?php endif; ?>

                                    <?php if($attributeValue->attribute->frontend_type == 'radio'): ?>
                                        <?php
                                            $i++;
                                            $modificators[] = [
                                                        'id' => $attributeValue->poster_id,
                                                        'price'          => $productAttribute->price,
                                                        'value'          => $attributeValue->value
                                                    ]
                                        ?>


                                            <input data-modificator id="modificator_<?php echo e($attributeValue->poster_id); ?>" class="checked-bg-dark-red checked-white dn" type="radio" name="active_modificator" value="<?php echo e($i); ?>"  checked >
                                            <label class=" ma2 w-100-l bg-white dark-red pa2 tc br-pill shadow-1 pointer flex items-center justify-center" for="modificator_<?php echo e($attributeValue->poster_id); ?>"><?php echo e($attributeValue->value); ?></label>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e(implode(', ', $ingredients)); ?>

                            <input type="hidden" name="ingredients" value="<?php echo e(implode(', ', $ingredients)); ?>">
                        </p>
                    </div>
                </div>

                <?php $__currentLoopData = $sharpness; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sharp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sharp->id == 1172): ?>
                        <div class="bg-black pa1 w2 nested-img absolute top-1 right-1 br-100">
                            <img src="<?php echo e('/storage/img/chili.svg'); ?>" alt="">
                        </div>

                    <?php endif; ?>

                    <?php if($sharp->id == 1173): ?>
                        <div class="bg-black pa1 w2 nested-img absolute top-1 right-1 br-100">
                            <img src="<?php echo e('/storage/img/herb.svg'); ?>" alt="">
                        </div>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="flex flex-column">
                    <p  class="self-end f4-l f7 mt2 mb1"><?php echo e(number_format($product->weight, '0', ',', ' ') . ' ' . $product->unit); ?></p>
                    <?php if(count($modificators) > 0 ): ?>
                        <?php $__currentLoopData = $modificators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $modificator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-product-controls="<?php echo e($modificator['id']); ?>" class=" <?php if(count($modificators) != $key + 1 ): ?> dn  <?php else: ?> flex <?php endif; ?> flex-column flex-row-ns justify-between items-center">
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <input type="hidden" name="uid[]" value="<?php echo e($modificator['id']); ?>">
                                <input type="hidden" name="modificator_value[]" value="<?php echo e($modificator['value']); ?>">
                                <input type="hidden" name="modificator_price[]" value="<?php echo e($modificator['price']); ?>">

                                <button data-control-add type="submit" name="action" value="add" class="<?php if(Cart::get($modificator['id'] )): ?> dn <?php endif; ?> order-2 order-1-ns w4 bg-dark-red tc white pa3 bn br-pill bg-animate hover-bg-red pointer">
                                    В корзину
                                </button>

                                <div data-control-update class="order-2 order-1-l <?php if(!Cart::get($modificator['id'])): ?> dn <?php endif; ?>" >
                                    <div class="flex bg-dark-red w4 white br-pill overflow-hidden ">
                                        <button name="action" value="decrease" type="submit" class="w-third bn  pv3 ph2 bg-inherit white bg-animate hover-bg-red pointer">-</button>
                                        <div data-control-quantity class="w-third tc pv3">
                                            <?php if(Cart::get($modificator['id'])): ?>
                                                <?php echo e(Cart::get($modificator['id'])['quantity']); ?>

                                            <?php endif; ?>
                                        </div>
                                        <button name="action" value="increase" type="submit" class="w-third bn  pv3 ph2 bg-inherit white bg-animate hover-bg-red pointer">+</button>
                                    </div>
                                </div>

                                <div class="order-1 order-2-ns fw5 tc tl-ns"><span class="f2"><?php echo e(number_format($modificator['price'], '0', ',', ' ')); ?></span> <span class="f4"> грн.</span></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div data-product-controls="<?php echo e($product->id); ?>" class="flex flex-column flex-row-ns justify-between items-center">
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <input type="hidden" name="uid" value="<?php echo e($product->id); ?>">

                            <button data-control-add type="submit" name="action" value="add" class="<?php if(Cart::get($product->id)): ?> dn <?php endif; ?> order-2 order-1-ns w4 bg-dark-red tc white pa3 bn br-pill bg-animate hover-bg-red pointer">
                                В корзину
                            </button>

                            <div data-control-update class="order-2 order-1-l <?php if(!Cart::get($product->id)): ?> dn <?php endif; ?>" >
                                <div class="flex bg-dark-red w4 white br-pill overflow-hidden ">
                                    <button name="action" value="decrease" type="submit" class="w-third bn  pv3 ph2 bg-inherit white bg-animate hover-bg-red pointer">-</button>
                                    <div data-control-quantity class="w-third tc pv3">
                                        <?php if(Cart::get($product->id)): ?>
                                            <?php echo e(Cart::get($product->id)['quantity']); ?>

                                        <?php endif; ?>
                                    </div>
                                    <button name="action" value="increase" type="submit" class="w-third bn  pv3 ph2 bg-inherit white bg-animate hover-bg-red pointer">+</button>
                                </div>
                            </div>

                            <div class="order-1 order-2-ns fw5 tc tl-ns"><span class="f2"><?php echo e(number_format($product->price, '0', ',', ' ')); ?></span> <span class="f4"> грн.</span></div>
                        </div>
                    <?php endif; ?>

                </div>
            </form>




        </div>
    </div>
</div>
<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\emojisushi\resources\views/site/product/thumb.blade.php ENDPATH**/ ?>