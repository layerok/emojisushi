<nav class="w-100 bt bb b--red mv2">
    <ul class="ma0 pv3 list flex justify-between items-center ph2 overflow-y-auto">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $cat->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value->items->count() > 0): ?>
                    <!-- вложенные пункты -->
                <?php else: ?>
                    <li class="mv1 flex-shrink-0">
                        <a class="ph3 pv1 br-pill link <?php if(isset($category)): ?> <?php if($value->slug == $category->slug): ?> bg-red <?php endif; ?> <?php endif; ?> hover-bg-red hover-white white " href="<?php echo e(route('category.show', $value->slug)); ?>">
                            <span class="ph1"><?php echo e($value->name); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav>
<!-- Slider main container -->
<div class="swiper-container">
    <!-- Additional required wrapper -->
    <div class="swiper-wrapper">
        <!-- Slides -->
        <div class="swiper-slide"><img src="/img/slide1.jpg" alt="Собери свой WOK"></div>
        <div class="swiper-slide"><img src="/img/slide2.jpg" alt="Бесплатная доставка"></div>
        <div class="swiper-slide"><img src="/img/slide3.jpg" alt="Sumoist Sushi & WOK"></div>
        <div class="swiper-slide"><img src="/img/slide4.jpg" alt="Бесплатная дегустация на торговой 15(7 небо) с 14:00 - 16:30"></div>
        <div class="swiper-slide"><img src="/img/slide5.jpg" alt="-20% на все кроме наборов с 13:00 - 16:00(пн-чт)"></div>

    </div>
    <!-- If we need pagination -->
    <div class="swiper-pagination"></div>

</div>

<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\ecommerce_new\ecom\resources\views/site/partials/nav.blade.php ENDPATH**/ ?>