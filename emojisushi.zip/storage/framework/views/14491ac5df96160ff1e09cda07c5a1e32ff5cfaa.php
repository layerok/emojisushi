<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center">
        <div class="w-100 mw7 ph3">
            <h2>Homepage</h2>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\ecommerce_new\ecom\resources\views/site/pages/homepage.blade.php ENDPATH**/ ?>