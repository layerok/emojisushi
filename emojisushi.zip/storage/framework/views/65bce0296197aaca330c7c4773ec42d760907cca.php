<!-- Корзина -->
<div  class="mh0  mh3-l pv2 order-0 flex items-center justify-end relative <?php if(isset($is_second_popup)): ?>  <?php else: ?> w-50 <?php endif; ?> "  ><!---->
    <div class="flex flex-shrink-0"  <?php if(isset($is_second_popup)): ?> data-layerok="#show-sign-modal_2" <?php else: ?> data-layerok="#show-sign-modal" <?php endif; ?>>

        <div class="nested-img pointer " >
            <img src="/img/cart.png" alt="Корзина">
        </div>
        <div class="flex flex-column justify-between ml3-ns pl2">
            <div  class="f4"><span data-cart-total><?php echo e(Cart::getTotal()); ?></span> грн.</div>
            <div ><span data-cart-total-quantity><?php echo e(Cart::getTotalQuantity()); ?></span> тов.</div>
        </div>






    </div>
    <div class="absolute right-0 top-3 z-4">
        <?php echo $__env->make('site.partials.cartPopUp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


</div>
<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\emojisushi\resources\views/site/partials/cart.blade.php ENDPATH**/ ?>