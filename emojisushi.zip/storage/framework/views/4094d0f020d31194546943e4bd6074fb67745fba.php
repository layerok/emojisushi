<?php $__env->startSection('title'); ?> <?php echo e($pageTitle); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-tags"></i> <?php echo e($pageTitle); ?></h1>
        </div>
    </div>
    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="tile">
                <h3 class="tile-title"><?php echo e($subTitle); ?></h3>
                <form action="<?php echo e(route('admin.categories.update')); ?>" method="POST" role="form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="tile-body">
                        <div class="form-group">
                            <label class="control-label" for="name">Имя <span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $targetCategory->name)); ?>"/>
                            <input type="hidden" name="id" value="<?php echo e($targetCategory->id); ?>">
                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="sort_order">Порядок сортировки <span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('sort_order')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sort_order'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="sort_order" id="sort_order" value="<?php echo e(old('sort_order', $targetCategory->sort_order)); ?>" />
                            <?php if ($errors->has('sort_order')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sort_order'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        

                        <div class="form-group">
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" id="hidden" name="hidden"
                                        <?php echo e($targetCategory->hidden == 0 ? 'checked' : ''); ?>

                                    />Активная
                                </label>
                            </div>
                        </div>
















                    </div>
                    <div class="tile-footer">
                        <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Обновить категорию</button>
                        &nbsp;&nbsp;&nbsp;
                        <a class="btn btn-secondary" href="<?php echo e(route('admin.categories.index')); ?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Отменить</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\emojisushi\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>