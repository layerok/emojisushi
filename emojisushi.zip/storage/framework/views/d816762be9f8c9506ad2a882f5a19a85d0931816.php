<script src="<?php echo e(asset('frontend/js/jquery-2.0.0.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('frontend/plugins/fancybox/fancybox.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('frontend/plugins/owlcarousel/owl.carousel.min.js')); ?>"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="<?php echo e(asset('frontend/js/script.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('backend/js/app.js')); ?>"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\ecommerce_new\ecom\resources\views/site/partials/scripts.blade.php ENDPATH**/ ?>