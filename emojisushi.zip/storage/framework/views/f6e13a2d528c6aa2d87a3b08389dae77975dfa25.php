<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">

<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontend/images/favicon.ico')); ?>">
<link href="<?php echo e(asset('frontend/fonts/fontawesome/css/fontawesome-all.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/fancybox/fancybox.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/owlcarousel/assets/owl.theme.default.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/ui.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet" media="only screen and (max-width: 1200px)" />
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/tachyons.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom-tachyons.css')); ?>"/>
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css">
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\ecommerce_new\ecom\resources\views/site/partials/styles.blade.php ENDPATH**/ ?>