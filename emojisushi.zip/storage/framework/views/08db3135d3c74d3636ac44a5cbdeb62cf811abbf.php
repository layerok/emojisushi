<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
    <ul class="app-menu">
        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="app-menu__icon fa fa-dashboard"></i>
                <span class="app-menu__label">Админка</span>
            </a>
        </li>
        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.products.index' ? 'active' : ''); ?>" href="<?php echo e(route('admin.products.index')); ?>">
                <i class="app-menu__icon fa fa-shopping-bag"></i>
                <span class="app-menu__label">Продукты</span>
            </a>
        </li>
        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.categories.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('admin.categories.index')); ?>">
                <i class="app-menu__icon fa fa-tags"></i>
                <span class="app-menu__label">Категории</span>
            </a>
        </li>
        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.ingredients.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('admin.ingredients.index')); ?>">
                <i class="app-menu__icon fa fa-carrot"></i>
                <span class="app-menu__label">Ингридиенты</span>
            </a>
        </li>
        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.ingredients.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('admin.ingredients.index')); ?>">
                <i class="app-menu__icon fas fa-store"></i>
                <span class="app-menu__label">Заведения</span>
            </a>
        </li>
        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.attributes.index' ? 'active' : ''); ?>" href="<?php echo e(route('admin.attributes.index')); ?>">
                <i class="app-menu__icon fa fa-th"></i>
                <span class="app-menu__label">Аттрибуты</span>
            </a>
        </li>

        <li>
            <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.settings' ? 'active' : ''); ?>" href="<?php echo e(route('admin.settings')); ?>">
                <i class="app-menu__icon fa fa-cogs"></i>
                <span class="app-menu__label">Настройки</span>
            </a>
        </li>
    </ul>
</aside>
<?php /**PATH C:\Users\Fofan\Desktop\веб-проекты\laravel\ecommerce_new\ecom\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>